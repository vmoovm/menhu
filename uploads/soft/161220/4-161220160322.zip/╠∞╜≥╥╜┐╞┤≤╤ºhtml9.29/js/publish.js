$(function(){
	$(".selectBox").hover(function(){
		$(this).find("ul").show();
		$(this).find("p").addClass("t")
	},function(){
		$(this).find("ul").hide();	
		$(this).find("p").removeClass("t")
	})	
	
	$(".delete").click(function(){
		$(".deleteCon").show();
	})
	$(".submitsnone").click(function(){
	$(this).parent().parent().hide();
	})
	
	$(".fiveTips").toggle(function(){
	$(this).next(".fjThree").show();
	},function(){
		$(this).next(".fjThree").hide();
		})
})

