function setLayout(){
	j=0;
	for(var i=1000;i>=$('.lock').length;i--){
		$('.lock').eq(j++).css({'z-index':i});
	}
}
setLayout();
$('.timeline .lock').click(function(){
$('.winpop').hide();	
$(this).find('.winpop').show();	


});
$('.btn02').click(function(){
	
$(this).parent().parent().parent().parent().hide();	
return false;

});

//tabs切换
$('.tabs').tabs({
switchMode:"click"	
});

$('.answerclick .showone').click(function(){

if($(this).parent().next().css('display')=='none'){
	$(this).parent().next().show();
	$(this).text('回复 2条');
	}else{
	$(this).parent().next().hide();	
	$(this).text('回复 2条');
	}

	
	
});

$('.inputwordsone').disappearDefault({

vals:"默认属性",

defaultColor:"#999",	

color:"#333",

callback:function(o){
	
o.next().show();

},

showDefault:true
	
});


$('.inputwordstwo').disappearDefault({

vals:"默认属性",

defaultColor:"#999",	

color:"#333",

callback:function(o){
o.hide();	
o.next().show();

},

showDefault:true
	
});

$('.bgimage').hover(function(){
$(this).children('.mask').show();	
	
},function(){
$(this).children('.mask').hide();	
	

});