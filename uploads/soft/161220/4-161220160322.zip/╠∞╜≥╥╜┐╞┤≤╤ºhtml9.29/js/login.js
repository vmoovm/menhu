// JavaScript Document

$(function(){
		 $(".loginInp").focus(function () {
                $(this).addClass("loginInp02")
            })
	$(".loginInp").blur(function () {
		if ($(this).val()=="") {
			$(this).removeClass("loginInp02")
		}
	})
	$(".loginSub").focus(function(){
			$(this).addClass("loginInp02")
		})
	$(".loginSub").blur(function () {
		if ($(this).val()=="") {
			$(this).removeClass("loginInp02")
		}
	})
});