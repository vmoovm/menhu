﻿$(document).ready(function(){
	maphover();
});

function maphover(){
	var self = "";
	$(".city").hover(
		function(){
			self = $(this);
			self.addClass("hover").find(".citybg").show();
		},
		function(){
			self = $(this);
			self.find(".citybg").hide();
			self.removeClass("hover");
		}
	);
	function classLie(){
		var num=$('#zma_lie').find('ul').length;
		if(num<5){
			$('#zma_lie').attr('class','zma_lie'+num);
		}
		$('#zma_lie').show(50);
	}
	
	$('.zma_close').click(function(){
		var target;
		$('#zma_lie').hide();
		
		return false
	});
	
	$(".city").click(function(){
			classLie();
			$(this).after($('#zma_lie'));
			var zright=$(this).find('.citybg').offset().left;
			var ztop=$(this).find('.citybg').position().top,
				zwidth=$(this).find('.citybg').width(),
				zleft=$(this).find('.citybg').position().left+zwidth;
			$('#zma_lie').css({'left':zleft,'top':ztop});
			if((zright+$('#zma_lie').width())>$(window).width()) $('#zma_lie').css({'left':'auto'});
			$('.citybg').hide();
			self = $(this);
			self.addClass("hover").find(".citybg").show();
		}
	);
		
};
