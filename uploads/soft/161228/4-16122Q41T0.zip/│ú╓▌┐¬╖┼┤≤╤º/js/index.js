﻿// JavaScript Document
	$(function(){
	/*banner*/
	$('#zbanner').fullScreenSwitch({
		pointOff:'zb_off',
		pointOn:'zb_on',
		pointHtml:'a',
		btn_l_h:'left_h',
		btn_r_h:'right_h',
		isBtn:false,
		showBtn:true,
		isPoint:false,
		isAuto:true,
		speed:3000,
		minW:1190,
		LorR:0
	});
	/*nav*/
	$('#zh_nav').tab({
		myevent:'mouseover',
		contentCss:'.zh_n_sub',
		titleOff:'zh_n_item',
		titleOn:'zh_n_cur'
	});
	/*recommend & hot*/
	$('.zr_tab').tab({
		myevent:'mouseover',
		contentCss:'.zr_box',
		titleOff:'zr_off',
		titleOn:'zr_on',
		btn:'span' 
	});
	$('.zr_box li').mouseover(function(){
		$(this).siblings().removeAttr('class');
		$(this).addClass('zr_cur').siblings().removeClass('zr_cur');
		$(this).find('p').show();
		$(this).siblings().find('p').hide();
		$(this).find('h2').hide();
		$(this).siblings().find('h2').show();
	}).mouseout(function(){
		$(this).siblings().removeAttr('class');
	});
	/*search*/
	$('#zh_s_input').defaultInput({
		text:'请输入关键字',
		color:'#000',
		gray:'#536074'
	});
	
	//
	$('.zh_n_sub li').click(function(){
		var toId=$(this).attr('role');
		var toIdH=$(toId).position().top;
		$("body, html").animate({scrollTop: toIdH+"px"}, 550, function(){});
	});

});






























