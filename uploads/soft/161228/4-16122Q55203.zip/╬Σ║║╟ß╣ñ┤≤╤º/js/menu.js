(function($){

	$.fn.selects = function(){
	    var $that = $(this);

		$that.on('click', $that.children().eq(0), null, function(){
			$that.children().eq(1).show();
			return false;
		});
		
		$that.children().eq(1).on('click', $that.children().eq(1).children(), null, function(event){
			$that.children().eq(0).children().eq(0).html($(event.target).html());
			$that.children().eq(1).hide();
			return false;
		});
		$(document).on('click', function(){
		  if($that.children().eq(1).css('display') == 'block'){
		  	$that.children().eq(1).hide();
			return false;  
		  }	
		 	
		});
		
	
	}

})(jQuery);







