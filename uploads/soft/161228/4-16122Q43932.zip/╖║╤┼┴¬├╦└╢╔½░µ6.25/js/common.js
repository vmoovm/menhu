﻿$(function(){
	//登录后状态
	$('.zt_after_login').mouseenter(function(){
		if(!$(this).find('.zt_af_ul').is(':animated')) $(this).find('.zt_af_ul').slideDown(100);
	}).mouseleave(function(){
		$(this).find('.zt_af_ul').slideUp(100);
	});
	
	$('#zt_s_all').click(function(){
		$(this).find('p:first').addClass('zt_s_hover');
		$('#zt_s_box').show();
	}).mouseleave(function(){
		$(this).find('p:first').removeClass('zt_s_hover');
		$('#zt_s_box').hide();
	});
	
	$('.zt_s_con').on('mouseenter','.zt_s_item',function() {
		$(this).addClass('zt_s_over');
		$(this).find('.zt_s_sub').show();
		var n=$(this).find('.zt_s_sub').width();
		var n1=$(window).width()-($(this).offset().left+n);
		if(n1<n){
			$(this).find('.zt_s_sub').addClass('zt_s_sub2');
		}else{
			$(this).find('.zt_s_sub').removeClass('zt_s_sub2');
		}
	}).on('mouseleave','.zt_s_item',function() {
		$(this).removeClass('zt_s_over');
		$(this).find('.zt_s_sub').hide();
	});
});





























