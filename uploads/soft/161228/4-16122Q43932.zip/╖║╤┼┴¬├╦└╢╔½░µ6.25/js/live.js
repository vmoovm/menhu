﻿$(function(){
//初始化样式
var prev=$('.zar_l_prev');
var next=$('.zar_l_next');
var year=$('.zar_l_year');
var zday=$('#zday');
var zElem={
	start:'<span class="zar_l_day"><a href="#">',
	end:'</a></span>'
};
var css_cur='zar_l_cur';

//获取现在时间
var date=new Date();
var y=date.getFullYear();
var m=date.getMonth()+1;
var d=date.getDate();


//获取每月天数
function set_m(){
	var will=new Date(y,m,0);
	d=will.getDate();
}

//显示当月天数
function display_d(){
	var c_html='';
	zday.html('');
	for(i=0;i<d;i++){
		c_html=zElem.start+parseInt(i+1)+zElem.end;
		zday.append(c_html);
		zday.find(':first').attr('class',css_cur);
	}
}

//输出年月
function display_txt(){
	year.text(y+'.'+m);
}

set_m();
display_d();
display_txt();
	
//上一页
prev.click(function(){
	if(m<2){
		y--;
		m=12;
	}else{
		m--;
	}
	set_m();
	display_d();
	display_txt();
});

//下一月
next.click(function(){
	if(m>11){
		y++;
		m=1;
	}else{
		m++;
	}
	set_m();
	display_d();
	display_txt();
});
});

