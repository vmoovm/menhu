﻿$(function(){
	//课程banner
	$('#zkc_bannerbg').fullScreenSwitch({
		pointOff:'btn_off',
		pointOn:'btn_on',
		pointHtml:'a',
		btn_l_h:'left_h',
		btn_r_h:'right_h',
		isBtn:true,
		showBtn:true,
		isPoint:true,
		isAuto:true,
		isfull:true,
		speed:10000,
		minW:1100,
		LorR:0
	});
	
	$('#zkc_s_intext').defaultInput({
		text:'搜索课程、老师',
		color:'#fff',
		gray:'#fff',
	});
	//课程分类
	$('.zcu_row').mouseenter(function(){
		if(!$(this).find('.zcu_bg').is(':animated')){
			$(this).find('.zcu_bg').animate({'width':'100%'},200);
			$(this).find('.zcu_txt').addClass('zcu_hover');
		}
	}).mouseleave(function(){
		$(this).find('.zcu_bg').animate({'width':'7px'},200);
		$(this).find('.zcu_txt').removeClass('zcu_hover');
	});
	//课程列表
	$('#postion').fullScreenSwitch({
		pointOff:'btn_off',
		pointOn:'btn_on',
		pointHtml:'a',
		btn_l_h:'left_h',
		btn_r_h:'right_h',
		isBtn:true,
		showBtn:true,
		isPoint:true,
		isAuto:false,
		isfull:false,
		speed:3000,
		minW:1200,
		LorR:0
	});
	$('#jpkc').fullScreenSwitch({
		pointOff:'btn_off',
		pointOn:'btn_on',
		pointHtml:'a',
		btn_l_h:'left_h',
		btn_r_h:'right_h',
		isBtn:true,
		showBtn:true,
		isPoint:true,
		isAuto:false,
		isfull:false,
		speed:3000,
		minW:1200,
		LorR:0
	});
	
});





























