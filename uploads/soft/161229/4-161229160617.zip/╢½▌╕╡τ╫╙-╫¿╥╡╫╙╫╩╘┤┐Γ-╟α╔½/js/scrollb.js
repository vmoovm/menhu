var Scrl = function(){
		var t = this, body = document.getElementById("focus_img"),
		bWidth = NTES.one("#focus_img> div").offsetWidth * NTES("#focus_img> div").length;
		
		t._ctrls = $("#focus_menu> div"),
		t._len = t._ctrls.length,
		t._step = bWidth / t._len,
		t.index = 0;
		t._scrl = new NTES.ui.Scroll(body, 'x');
		t._ctrls.each(function(i){
			$(this).addEvent("mouseover", t.show.bind(t, i), i); 
		});
		NTES("#preimg").addEvent("click", function(e){ 
			e.preventDefault();
			t.show(--t.index);
		});
		NTES("#nextimg").addEvent("click", function(e){
			e.preventDefault();
			t.show(++t.index);
		});
		t.show(0);
	}
	Scrl.prototype = {
		show: function(i){
			var t = this;
			t.index = i < 0 ? t._len - 1 : i > t._len - 1 ? 0 : i;
			t._scrl.onStart = function(){
				t._ctrls.removeCss("showNow");
				t._ctrls.$(t.index).addCss("showNow");
			}
			t._scrl.scrollTo(t._step * t.index);
		}
	}
	function repeat(){
		fcs.show(++fcs.index);
	}
	var fcs = new Scrl();
	var timer = setInterval(repeat, 4000),slideBody=NTES("#scroll-box");
	slideBody.addEvent("mouseover", function(e){
		if(timer !== undefined){
			clearTimeout(timer);
			timer = undefined;
		}
	}).addEvent("mouseout", function(){
		if(timer === undefined){
			timer = setInterval(repeat, 4000);
		}
	});
	