
//推荐课程滚动效果

	/**
	主要样式 roll
		box
		boxdiv
		ul
		li
		
		rightBtn
		leftBtn
		
		rightBtnNone
		leftBtnNone
	*/
$(function(){
		//初始判断 左按钮
    $(".roll").each(function(i){    	
    		var win_width=$(this).find(".box").width(); //显示框宽度
    		var margin_width=$(this).find(".boxdiv ul li").outerWidth(true) - $(this).find(".boxdiv ul li").width() ;//得到横坐标上一个li的margin之和
    		var width=$(this).find(".boxdiv ul li").outerWidth(true) ;//单个li宽度 ，这里应该还有+margin
    		var init_li = Math.floor( (win_width+margin_width) / width); //显示框存放li最大个数
				var cur_left=0; //当前left值
				var li_num=$(this).find(".boxdiv ul li").length;//li个数
				var hide_li_num= li_num - init_li ;//隐藏最大个数
				
				var max_left=hide_li_num * width * -1; //最大left值
				var init_left=0; //最小left值
				
				var speed_width=width;//每次移动left量
				
				var ul_width = li_num * width;
				$(this).find(".ul_width").width(ul_width);//设置 ul_width 大小
				
				$(this).data("left",cur_left); //定义当前left值
				$(this).data("speed_width",speed_width); //定义每次行走宽度
    		$(this).data("max_left",max_left);//定义最大left值
    		
    		if(cur_left==0){
		    	$(this).find(".leftBtn").css("display","none");
		    	$(this).find(".leftBtnNone").css("display","");
		    }
		    //初始判断 右按钮
		    if(max_left >= init_left){
		    		$(this).find(".rightBtn").css("display","none");
		    		$(this).find(".rightBtnNone").css("display","");
		    }else{
		    		$(this).find(".rightBtn").css("display","");
		    		$(this).find(".rightBtnNone").css("display","none");
		    }
    	})
	
    $(".rightBtn").click(function(){//右按钮
    		var roll=$(this).parents(".roll:first");
    		var cur_left=$(roll).data("left");
    		var width=$(roll).data("speed_width");
    		cur_left=cur_left-width;
    		$(roll).data("left",cur_left);
    		clickBtn(roll)
    });
    
    $(".leftBtn").click(function(){//左按钮
    		var roll=$(this).parents(".roll:first");
    		var cur_left=$(roll).data("left");
    		var width=$(roll).data("speed_width");
    		cur_left=cur_left +width;
    		$(roll).data("left",cur_left);	
    		clickBtn(roll)
    });
    
    function clickBtn(f){
    	var cur_left=$(f).data("left");
    	var max_left=$(f).data("max_left");
    	$(f).find(".boxdiv").animate({"left":cur_left + "px"},500);
    		if(cur_left<=max_left){//右按钮
    			$(f).find(".rightBtn").css("display","none");
    			$(f).find(".rightBtnNone").css("display","");
    		}else{
    			$(f).find(".rightBtn").css("display","");
    			$(f).find(".rightBtnNone").css("display","none");
    		}
    		if(cur_left>=0){
		    	$(f).find(".leftBtn").css("display","none");
		    	$(f).find(".leftBtnNone").css("display","");
		    }else{
		    	$(f).find(".leftBtn").css("display","");
		    	$(f).find(".leftBtnNone").css("display","none");
		    }
    }
    
    
})

