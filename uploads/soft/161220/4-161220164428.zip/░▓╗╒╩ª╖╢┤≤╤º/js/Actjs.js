



/*+++++++++++++++++++下拉表单+++++++++++*/
function clicked(ele, e) {

	e = e || window.event;
	var ul = ele.getElementsByTagName("ul")[0];
	if (ul.style.display == "block") {
		
		ul.style.display = "none";
		$(".options").hide();
	} else {
		$(".options").hide();
		ul.style.display = "block";
	}
	// =  ? "none" : "block";
	stopPropagation(e);
	return false;
}

function checkIt(ele) {
	var p = ele.parentNode.parentNode.parentNode.getElementsByTagName("p")[0];
	p.innerHTML = ele.innerHTML;
	return false;
}

function stopPropagation(event) {
	if (event.stopPropagation) {
		event.stopPropagation();
	} else {
		event.cancelBubble = true;
	}
}
document.onclick = function() {
	$(".options").hide();
}
$(function()
{
	$(".Onfouce").click(function(){
		$(".MctInp").val("");
	})

});














